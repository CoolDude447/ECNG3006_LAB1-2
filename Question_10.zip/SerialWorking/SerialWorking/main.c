// Necessary includes
#include "atmel_start.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>
#include "semphr.h"

// Define tasks
void Task1(void *pvParameters);
void Task2(void *pvParameters);
void Task3(void *pvParameters);

// Create handles for tasks
TaskHandle_t xTask1Handle, xTask2Handle, xTask3Handle;

// Create IO descriptor
struct io_descriptor *io;

void Task1(void *pvParameters)
{
    while (1)
    {
        if (io != NULL)
        {
            io_write(io, (uint8_t *)"Task 1 running\r\n", 16);
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void Task2(void *pvParameters)
{
    while (1)
    {
        if (io != NULL)
        {
            io_write(io, (uint8_t *)"Task 2 running\r\n", 16);
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void Task3(void *pvParameters)
{
    while (1)
    {
        if (io != NULL)
        {
            io_write(io, (uint8_t *)"Task 3 running\r\n", 16);
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

int main(void)
{
    // Initialize system
    atmel_start_init();

    // Get IO descriptor for USART
    usart_sync_get_io_descriptor(&TARGET_IO, &io);

    // Set baud rate
    usart_sync_set_baud_rate(&TARGET_IO, 9600);

    // Enable USART
    usart_sync_enable(&TARGET_IO);

    // Debug: USART enabled
    if (io != NULL)
    {
        io_write(io, (uint8_t *)"USART Initialized\r\n", 19);
    }

    // Scenario 1: Same Priority Level for All Tasks
    io_write(io, (uint8_t *)"Running Scenario 1: Same Priority Level for All Tasks\r\n", 52);
    xTaskCreate(Task1, "Task 1", configMINIMAL_STACK_SIZE, NULL, 1, &xTask1Handle);
    xTaskCreate(Task2, "Task 2", configMINIMAL_STACK_SIZE, NULL, 1, &xTask2Handle);
    xTaskCreate(Task3, "Task 3", configMINIMAL_STACK_SIZE, NULL, 1, &xTask3Handle);

    // Scenario 2: Task 1 > Task 2 > Task 3 (run to completion)
    io_write(io, (uint8_t *)"Running Scenario 2: Task 1 > Task 2 > Task 3 (run to completion)\r\n", 64);
    xTaskCreate(Task1, "Task 1", configMINIMAL_STACK_SIZE, NULL, 3, &xTask1Handle);
    xTaskCreate(Task2, "Task 2", configMINIMAL_STACK_SIZE, NULL, 2, &xTask2Handle);
    xTaskCreate(Task3, "Task 3", configMINIMAL_STACK_SIZE, NULL, 1, &xTask3Handle);

    // Scenario 3: Task 1 > Task 2 > Task 3 (no priority inheritance)
    io_write(io, (uint8_t *)"Running Scenario 3: Task 1 > Task 2 > Task 3 (no priority inheritance)\r\n", 71);
    SemaphoreHandle_t xMutex = xSemaphoreCreateMutex();
    if (xMutex != NULL)
    {
        xSemaphoreGive(xMutex);
    }
    xTaskCreate(Task1, "Task 1", configMINIMAL_STACK_SIZE, (void *)xMutex, 3, &xTask1Handle);
    xTaskCreate(Task2, "Task 2", configMINIMAL_STACK_SIZE, (void *)xMutex, 2, &xTask2Handle);
    xTaskCreate(Task3, "Task 3", configMINIMAL_STACK_SIZE, (void *)xMutex, 1, &xTask3Handle);

    // Scenario 4: Task 1 > Task 2 > Task 3 (priority inheritance enabled)
    io_write(io, (uint8_t *)"Running Scenario 4: Task 1 > Task 2 > Task 3 (priority inheritance enabled)\r\n", 76);
    SemaphoreHandle_t xMutexPriInherit = xSemaphoreCreateMutex();
    if (xMutexPriInherit != NULL)
    {
        xSemaphoreGive(xMutexPriInherit);
    }
    xTaskCreate(Task1, "Task 1", configMINIMAL_STACK_SIZE, (void *)xMutexPriInherit, 3, &xTask1Handle);
    xTaskCreate(Task2, "Task 2", configMINIMAL_STACK_SIZE, (void *)xMutexPriInherit, 2, &xTask2Handle);
    xTaskCreate(Task3, "Task 3", configMINIMAL_STACK_SIZE, (void *)xMutexPriInherit, 1, &xTask3Handle);

    // Start scheduler
    vTaskStartScheduler();

    // Infinite loop (should never reach here)
    while (1)
    {
    }
}

// Stack overflow hook
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    // Handle stack overflow here
    for (;;);
}

// Malloc failed hook
void vApplicationMallocFailedHook(void)
{
    // Handle malloc failure here
    for (;;);
}

// Notes for Upload
// - Capture evidence by video/pictures/screenshots and serial UART output via PuTTY.
// - For scenarios b and c, use mutex to demonstrate behavior with and without priority inheritance.
// - Provide captured evidence in GitHub repository.